# Copyright 2009-2010 Ram Rachum. No part of this program may be used, copied
# or distributed without explicit written permission from Ram Rachum.

'''
Defines the BlockMenu class.

See its documentation for more info.
'''

from block_menu import BlockMenu
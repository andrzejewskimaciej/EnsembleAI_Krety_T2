# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''This module monkey-patches the pickling dispatch table using `copy_reg`.'''

# todo: alters global state, yuck! Maybe check before if it's already set to
# something?

import copy_reg
import types
import __builtin__


###############################################################################

def reduce_method(method):
    '''Reducer for methods.'''
    return (
        getattr,
        (
            
            method.im_self or method.im_class,
            # im_self for bound methods, im_class for unbound methods.
            
            method.im_func.__name__
        
        )
    )

copy_reg.pickle(types.MethodType, reduce_method)


###############################################################################


def __import__(*args, **kwargs):
    '''Wrapper for the builtin `__import__`'''
    # todo: This is needed when debugging in Wing, cause Wing replaces
    # `__import__` with its own. This feels bad.
    return __builtin__.__import__(*args, **kwargs)

def reduce_module(module):
    '''Reducer for modules.'''
    return (__import__, (module.__name__, {}, {}, [''])) # fromlist cruft

copy_reg.pickle(types.ModuleType, reduce_module)


###############################################################################


def _get_ellipsis():
    return Ellipsis

def reduce_ellipsis(method):
    return (
        _get_ellipsis,
        ()
    )

copy_reg.pickle(types.EllipsisType, reduce_ellipsis)


###############################################################################
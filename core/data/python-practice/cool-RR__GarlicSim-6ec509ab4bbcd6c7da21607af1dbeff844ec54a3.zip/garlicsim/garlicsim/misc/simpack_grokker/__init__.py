# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
This package defines the SimpackGrokker class in the module simpack_grokker.py.
See its documentation for more information.
'''

from simpack_grokker import SimpackGrokker

__all__ = ["SimpackGrokker"]
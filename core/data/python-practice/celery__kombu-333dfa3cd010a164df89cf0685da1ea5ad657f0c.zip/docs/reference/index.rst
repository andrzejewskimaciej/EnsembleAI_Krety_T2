===========================
 API Reference
===========================

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2

    kombu
    kombu.common
    kombu.mixins
    kombu.simple
    kombu.clocks
    kombu.compat
    kombu.pidbox
    kombu.exceptions
    kombu.log
    kombu.connection
    kombu.compression
    kombu.pools
    kombu.abstract
    kombu.syn
    kombu.transport
    kombu.transport.amqplib
    kombu.transport.librabbitmq
    kombu.transport.pyamqp
    kombu.transport.pika
    kombu.transport.pika2
    kombu.transport.memory
    kombu.transport.redis
    kombu.transport.zmq
    kombu.transport.beanstalk
    kombu.transport.mongodb
    kombu.transport.couchdb
    kombu.transport.zookeeper
    kombu.transport.filesystem
    kombu.transport.django
    kombu.transport.django.models
    kombu.transport.django.managers
    kombu.transport.django.management.commands.clean_kombu_messages
    kombu.transport.sqlalchemy
    kombu.transport.sqlalchemy.models
    kombu.transport.SQS
    kombu.transport.base
    kombu.transport.virtual
    kombu.transport.virtual.exchange
    kombu.transport.virtual.scheduling
    kombu.serialization
    kombu.utils
    kombu.utils.limits
    kombu.utils.compat
    kombu.utils.debug
    kombu.utils.encoding
    kombu.utils.functional
    kombu.utils.finalize
    kombu.utils.url

# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''Testing module for `garlicsim.general_misc.sequence_tools.combinations`.'''

import nose.tools

from garlicsim.general_misc.sequence_tools import combinations
from garlicsim.general_misc import sequence_tools


def test():
    '''Test basic workings of `combinations`.'''
    my_range = [0, 1, 2, 3, 4]
    
    
    assert list(combinations(xrange(4), n=2)) == [
        [0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]
    ]
    
    assert list(combinations(xrange(4), 3)) == [
        [0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]
    ]
    
    assert tuple(combinations('meowfrr', 5)) == (
        ['m', 'e', 'o', 'w', 'f'], ['m', 'e', 'o', 'w', 'r'],
        ['m', 'e', 'o', 'w', 'r'], ['m', 'e', 'o', 'f', 'r'],
        ['m', 'e', 'o', 'f', 'r'], ['m', 'e', 'o', 'r', 'r'],
        ['m', 'e', 'w', 'f', 'r'], ['m', 'e', 'w', 'f', 'r'],
        ['m', 'e', 'w', 'r', 'r'], ['m', 'e', 'f', 'r', 'r'],
        ['m', 'o', 'w', 'f', 'r'], ['m', 'o', 'w', 'f', 'r'],
        ['m', 'o', 'w', 'r', 'r'], ['m', 'o', 'f', 'r', 'r'],
        ['m', 'w', 'f', 'r', 'r'], ['e', 'o', 'w', 'f', 'r'],
        ['e', 'o', 'w', 'f', 'r'], ['e', 'o', 'w', 'r', 'r'],
        ['e', 'o', 'f', 'r', 'r'], ['e', 'w', 'f', 'r', 'r'],
        ['o', 'w', 'f', 'r', 'r']
    )
    
    assert list(combinations(xrange(5), n=2, start=2)) == \
           list(combinations(xrange(2, 5), n=2))
    
    
def test_all_sizes():
    '''Test using `n=None` so combinations of all sizes are returned.'''
    assert list(combinations(xrange(4))) == sequence_tools.flatten(
        list(combinations(xrange(4), i)) for i in xrange(1, 4+1)
    )
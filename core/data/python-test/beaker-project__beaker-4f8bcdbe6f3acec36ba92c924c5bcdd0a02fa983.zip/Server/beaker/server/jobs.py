# Logan - Logan is the scheduling piece of the Beaker project
#
# Copyright (C) 2008 bpeck@redhat.com
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from turbogears.database import session
from turbogears import controllers, expose, flash, widgets, validate, error_handler, validators, redirect, paginate
from turbogears import identity, redirect
from cherrypy import request, response
from kid import Element
from beaker.server.widgets import myPaginateDataGrid
from beaker.server.xmlrpccontroller import RPCRoot
import datetime
from turbogears.scheduler import add_interval_task

import cherrypy

from model import *
import string

class Jobs(RPCRoot):
    # For XMLRPC methods in this class.
    exposed = True

    upload = widgets.FileField(name='job_xml', label='Job XML')
    form = widgets.TableForm(
        'jobs',
        fields = [upload],
        action = 'save_data',
        submit_text = _(u'Submit Data')
    )

    @expose(template='beaker.server.templates.form-post')
    @identity.require(identity.not_anonymous())
    def new(self, **kw):
        return dict(
            title = 'New Job',
            form = self.form,
            action = './save',
            options = {},
            value = kw,
        )

    @cherrypy.expose
    def upload(self, job_xml):
        """
        XMLRPC method to upload job
        """
        return (1,'Success')

    @expose()
    @identity.require(identity.not_anonymous())
    def save(self, job_xml, *args, **kw):
        """
        TurboGears method to upload job xml
        """
        import xmltramp
        from jobxml import *
        xml = xmltramp.parse(job_xml.file.read())
        xmljob = XmlJob(xml)
        try:
            job = self.process_xmljob(xmljob,identity.current.user_id)
        except ValueError, err:
            session.rollback()
            flash(_(u'Failed to import job because of %s' % err ))
            redirect(".")

        session.save_or_update(job)
        session.flush()
        flash(_(u'Success!'))
        redirect(".")

    def process_xmljob(self, xmljob, userid):
        print xmljob.workflow
        print xmljob.whiteboard
        job = Job(whiteboard='%s' % xmljob.whiteboard,
                  owner_id=userid)
        for xmlrecipeSet in xmljob.iter_recipeSets():
            recipeSet = RecipeSet()
            for xmlrecipe in xmlrecipeSet.iter_recipes():
                recipe = self.handleRecipe(xmlrecipe)
                recipeSet.recipes.append(recipe)
                # We want the guests to be part of the same recipeSet
                for guest in recipe.guests:
                    recipeSet.recipes.append(guest)
            job.recipesets.append(recipeSet)    
        return job

    def handleRecipe(self, xmlrecipe, guest=False):
        if not guest:
            recipe = MachineRecipe()
            for xmlguest in xmlrecipe.iter_guests():
                guestrecipe = self.handleRecipe(xmlguest, guest=True)
                recipe.guests.append(guestrecipe)
        else:
            recipe = GuestRecipe()
            recipe.guestname = xmlrecipe.guestname
            recipe.guestargs = xmlrecipe.guestargs
        recipe.host_requires = xmlrecipe.hostRequires()
        recipe.distro_requires = xmlrecipe.distroRequires()
        for xmltest in xmlrecipe.iter_tests():
            recipetest = RecipeTest()
            try:
                test = Test.by_name(xmltest.name)
            except:
                raise ValueError('Invalid Test: %s' % xmltest.name)
            recipetest.test = test
            recipetest.role = xmltest.role
            for xmlparam in xmltest.iter_params():
                param = RecipeTestParam( name=xmlparam.name, 
                                        value=xmlparam.value)
                recipetest.params.append(param)
            recipe.tests.append(recipetest)
        return recipe

    @expose(format='json')
    def to_xml(self, id):
        jobxml = Job.by_id(id).to_xml().toxml()
        return dict(xml=jobxml)

    @expose(template='beaker.server.templates.grid')
    @paginate('list',default_order='id')
    def index(self, *args, **kw):
        jobs = session.query(Job).join('status').join('owner').order_by(job_table.c.id.desc())
        jobs_grid = myPaginateDataGrid(fields=[
		     widgets.PaginateDataGrid.Column(name='id', getter=lambda x:x.id, title='ID', options=dict(sortable=True)),
		     widgets.PaginateDataGrid.Column(name='whiteboard', getter=lambda x:x.whiteboard, title='Whiteboard', options=dict(sortable=True)),
		     widgets.PaginateDataGrid.Column(name='owner.email_address', getter=lambda x:x.owner.email_address, title='Owner', options=dict(sortable=True)),
		     widgets.PaginateDataGrid.Column(name='status.status', getter=lambda x:x.status, title='Status', options=dict(sortable=True)),
		     widgets.PaginateDataGrid.Column(name='result.result', getter=lambda x:x.result, title='Result', options=dict(sortable=True)),
                    ])
        return dict(title="Jobs", grid=jobs_grid, list=jobs, search_bar=None)

# This doesn't do anything usefull yet.  just experimenting.
def schedule_recipe_sets(*args):
    print "Entering Scheduler at %s " % args[0]()
    for rs in RecipeSet.iter_recipeSets():
        print rs
    print "Exiting..."

def schedule():
    add_interval_task(action=schedule_recipe_sets, 
                      args=[lambda:datetime.now()],
                      interval=120)


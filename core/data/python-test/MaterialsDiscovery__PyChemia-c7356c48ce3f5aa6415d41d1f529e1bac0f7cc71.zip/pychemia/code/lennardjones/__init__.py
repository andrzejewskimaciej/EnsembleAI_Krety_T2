from .lj import LennardJones

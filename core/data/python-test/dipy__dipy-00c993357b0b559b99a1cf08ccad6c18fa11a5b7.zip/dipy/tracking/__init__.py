#init for tracking module


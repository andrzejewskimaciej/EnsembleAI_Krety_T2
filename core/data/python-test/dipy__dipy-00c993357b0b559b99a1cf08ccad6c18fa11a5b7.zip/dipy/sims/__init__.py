#init for simulations

==============
 Introduction
==============

These pages describe a git_ and github_ workflow for the `dipy`_
project.

There are several different workflows here, for different ways of
working with *dipy*.

This is not a comprehensive git reference, it's just a workflow for our
own project.  It's tailored to the github hosting service. You may well
find better or quicker ways of getting stuff done with git, but these
should get you started.

For general resources for learning git, see :ref:`git-resources`.

.. include:: links.inc


# vim: set fileencoding=utf-8:

# Beaker
#
# Copyright (C) 2010 Red Hat, Inc.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import unittest
import datetime
import logging
from urlparse import urljoin
from urllib import urlencode, quote
import rdflib.graph
from turbogears.database import session

from bkr.inttest import data_setup, get_server_base, \
        assertions, with_transaction
from bkr.server.model import Arch, Key, Key_Value_String, Key_Value_Int, System, \
        Provision, ProvisionFamily, ProvisionFamilyUpdate, Hypervisor, \
        SystemStatus, LabInfo
from bkr.inttest.server.selenium import SeleniumTestCase, WebDriverTestCase
from bkr.inttest.server.webdriver_utils import login, check_system_search_results
from selenium.webdriver.support.ui import Select
from bkr.inttest.assertions import wait_for_condition

class SystemViewTestWD(WebDriverTestCase):

    def setUp(self):
        with session.begin():
            self.lab_controller = data_setup.create_labcontroller()
            self.user = data_setup.create_user(password=u'password')
            self.system = data_setup.create_system(lab_controller=self.lab_controller)
            self.distro_tree = data_setup.create_distro_tree(
                    lab_controllers=[self.lab_controller])

        self.browser = self.get_browser()

    def tearDown(self):
        self.browser.quit()

    #https://bugzilla.redhat.com/show_bug.cgi?id=886875
    def test_kernel_install_options_propagated_view(self):

        with session.begin():
            self.system.provisions[self.distro_tree.arch] = \
                Provision(arch=self.distro_tree.arch,
                          ks_meta = u'key1=value1 key1=value2 key2=value key3',
                          kernel_options=u'key1=value1 key1=value2 key2=value key3',
                          kernel_options_post=u'key1=value1 key1=value2 key2=value key3')

        b = self.browser
        login(b)
        b.get(get_server_base() + 'view/%s' % self.system.fqdn)

        # provision tab
        b.find_element_by_link_text('Provision').click()

        # select the distro
        Select(b.find_element_by_name('prov_install'))\
            .select_by_visible_text(unicode(self.distro_tree))

        # check the kernel install options field
        def provision_ks_meta_populated():
            if b.find_element_by_xpath("//input[@id='provision_ks_meta']")\
                    .get_attribute('value') == \
                    u'key1=value1 key1=value2 key2=value key3':
                return True



        # check the kernel install options field
        def provision_koptions_populated():
            if b.find_element_by_xpath("//input[@id='provision_koptions']")\
                    .get_attribute('value') == \
                    u'key1=value1 key1=value2 key2=value key3 noverifyssl':
                return True

        # check the kernel post install options field
        def provision_koptions_post_populated():
            if b.find_element_by_xpath("//input[@id='provision_koptions_post']")\
                    .get_attribute('value') == \
                    'key1=value1 key1=value2 key2=value key3':
                return True


        wait_for_condition(provision_ks_meta_populated)
        wait_for_condition(provision_koptions_populated)
        wait_for_condition(provision_koptions_post_populated)

    # https://bugzilla.redhat.com/show_bug.cgi?id=987313
    def test_labinfo_not_visible_for_new_systems(self):
        b = self.browser
        login(b)
        b.get(get_server_base() + 'view/%s' % self.system.fqdn)
        b.find_element_by_xpath('//ul[@class="nav nav-tabs" and '
                'not(.//a/text()="Lab Info")]')

    # https://bugzilla.redhat.com/show_bug.cgi?id=920018
    def test_system_not_visible_available_free_when_lc_disabled(self):
        with session.begin():
            lc1 = data_setup.create_labcontroller()
            lc2 = data_setup.create_labcontroller()
            system1 = data_setup.create_system(fqdn=data_setup.unique_name(u'aaaa%s.testdata'))
            system1.lab_controller = lc1
            system2 = data_setup.create_system(fqdn=data_setup.unique_name(u'aaaa%s.testdata'))
            system2.lab_controller = lc2

            # set lc2 to disabled
            lc2.disabled = True

        b = self.browser
        login(b)

        b.get(get_server_base())
        check_system_search_results(b, present=[system1,system2], absent=[])

        b.get(get_server_base()+'available')
        check_system_search_results(b, present=[system1, system2], absent=[])

        b.get(get_server_base()+'free')
        check_system_search_results(b, present=[system1], absent=[system2])

class SystemViewTest(SeleniumTestCase):

    @with_transaction
    def setUp(self):
        self.lab_controller = data_setup.create_labcontroller()
        self.system_owner = data_setup.create_user()
        self.unprivileged_user = data_setup.create_user(password=u'password')
        self.distro_tree = data_setup.create_distro_tree(
                lab_controllers=[self.lab_controller])
        self.system = data_setup.create_system(owner=self.system_owner,
                status=u'Automated', arch=u'i386')
        self.system.provisions[self.distro_tree.arch] = Provision(
                arch=self.distro_tree.arch, ks_meta=u'some_ks_meta_var=1',
                kernel_options=u'some_kernel_option=1',
                kernel_options_post=u'some_kernel_option=2')
        self.system.provisions[self.distro_tree.arch]\
            .provision_families[self.distro_tree.distro.osversion.osmajor] = \
                ProvisionFamily(osmajor=self.distro_tree.distro.osversion.osmajor,
                    ks_meta=u'some_ks_meta_var=2', kernel_options=u'some_kernel_option=3',
                    kernel_options_post=u'some_kernel_option=4')
        self.system.provisions[self.distro_tree.arch]\
            .provision_families[self.distro_tree.distro.osversion.osmajor]\
            .provision_family_updates[self.distro_tree.distro.osversion] = \
                ProvisionFamilyUpdate(osversion=self.distro_tree.distro.osversion,
                    ks_meta=u'some_ks_meta_var=3', kernel_options=u'some_kernel_option=5',
                    kernel_options_post=u'some_kernel_option=6')
        self.system.lab_controller = self.lab_controller
        self.selenium = self.get_selenium()
        self.selenium.start()

    def tearDown(self):
        self.selenium.stop()


    def go_to_system_edit(self, system=None):
        if system is None:
            system = self.system
        sel = self.selenium
        sel.open('')
        sel.wait_for_page_to_load('30000')
        sel.type('simplesearch', system.fqdn)
        sel.submit('id=simpleform')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), 'Systems')
        sel.click('link=%s' % system.fqdn)
        sel.wait_for_page_to_load('30000')
        sel.click('link=Edit System')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), system.fqdn)

    def go_to_system_view(self, system=None):
        if system is None:
            system = self.system
        sel = self.selenium
        sel.open('')
        sel.wait_for_page_to_load('30000')
        sel.type('simplesearch', system.fqdn)
        sel.submit('id=simpleform')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), 'Systems')
        sel.click('link=%s' % system.fqdn)
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), system.fqdn)

    def test_system_view_condition_report(self):
        sel = self.selenium
        self.login()
        self.go_to_system_view()
        self.assertFalse(sel.is_visible('//div[@id="condition_report_row"]'))
        with session.begin():
            self.system.status = SystemStatus.broken
        self.go_to_system_view()
        self.assertTrue(sel.is_visible('//div[@id="condition_report_row"]'))

    def test_current_job(self):
        sel = self.selenium
        self.login()
        with session.begin():
            job = data_setup.create_job(owner=self.system.owner,
                    distro_tree=self.distro_tree)
            data_setup.mark_job_running(job, system=self.system)
            job_id = job.id
        self.go_to_system_view()
        sel.click('link=(Current Job)')
        sel.wait_for_page_to_load('30000')
        self.assert_('J:%s' % job_id in sel.get_title())

    # https://bugzilla.redhat.com/show_bug.cgi?id=631421
    def test_page_title_shows_fqdn(self):
        self.go_to_system_view()
        self.assertEquals(self.selenium.get_title(), self.system.fqdn)

    def test_links_to_cc_change(self):
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click( # link inside cell beside "Notify CC" cell
                '//div[normalize-space(label/text())="Notify CC"]'
                '//a[normalize-space(string(.))="Change"]')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(self.selenium.get_title(),
                'Notify CC list for %s' % self.system.fqdn)

    # https://bugzilla.redhat.com/show_bug.cgi?id=747086
    def test_update_system_no_lc(self):
        with session.begin():
            system = data_setup.create_system()
            system.labcontroller = None
        self.login()
        sel = self.selenium
        self.go_to_system_edit(system=system)
        new_fqdn = 'zx81.example.com'
        sel.type('fqdn', new_fqdn)
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assert_system_view_text('fqdn', new_fqdn)

    def test_update_system(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        changes = {
            'fqdn': 'zx80.example.com',
            'vendor': 'Sinclair',
            'model': 'ZX80',
            'serial': '12345',
            'mac_address': 'aa:bb:cc:dd:ee:ff',
        }
        for k, v in changes.iteritems():
            sel.type(k, v)
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        for k, v in changes.iteritems():
            self.assert_system_view_text(k, v)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_change_status(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.select('status', u'Broken')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assert_system_view_text('status', u'Broken')
        with session.begin():
            session.refresh(self.system)
            self.assertEqual(self.system.status, SystemStatus.broken)
            self.assertEqual(len(self.system.status_durations), 2)
            self.assertEqual(self.system.status_durations[0].status,
                    SystemStatus.broken)
            assertions.assert_datetime_within(
                    self.system.status_durations[0].start_time,
                    tolerance=datetime.timedelta(seconds=60),
                    reference=datetime.datetime.utcnow())
            self.assert_(self.system.status_durations[0].finish_time is None)
            self.assert_(self.system.status_durations[1].finish_time is not None)
            assertions.assert_durations_not_overlapping(
                    self.system.status_durations)
            self.assert_(self.system.date_modified > orig_date_modified)

    # https://bugzilla.redhat.com/show_bug.cgi?id=746774
    def test_change_status_with_same_timestamps(self):
        # create two SystemStatusDuration rows with the same timestamp
        # (that is, within the same second)
        with session.begin():
            self.system.status = SystemStatus.removed
            session.flush()
            self.system.status = SystemStatus.automated
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        self.go_to_system_edit()
        sel.select('status', u'Broken')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), self.system.fqdn)
        self.assert_system_view_text('status', u'Broken')

    def test_strips_surrounding_whitespace_from_fqdn(self):
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.type('fqdn', '    lol    ')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('//h1'), 'lol')

    def test_rejects_malformed_fqdn(self):
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.type('fqdn', 'lol...?')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.control-group.error .help-inline'),
                'The supplied value is not a valid hostname')

    def test_rejects_non_ascii_chars_in_fqdn(self):
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.type('fqdn', u'lööööl')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.control-group.error .help-inline'),
                'The supplied value is not a valid hostname')

    # https://bugzilla.redhat.com/show_bug.cgi?id=683003
    def test_forces_fqdn_to_lowercase(self):
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.type('fqdn', 'LooOOooL')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('//h1'), 'looooool')

    def test_add_arch(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Arch(s)"]')
        sel.type('arch.text', 's390')
        sel.submit('name=arches')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_xpath_count(
                '//div[@id="arches"]'
                '//td[normalize-space(text())="s390"]'), 1)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    # https://bugzilla.redhat.com/show_bug.cgi?id=677951
    def test_add_nonexistent_arch(self):
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Arch(s)"]')
        sel.type('arch.text', 'notexist')
        sel.submit('name=arches')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'), u'No such arch notexist')

    def test_remove_arch(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Arch(s)"]')
        self.assertEquals(sel.get_xpath_count(
                '//div[@id="arches"]'
                '//td[normalize-space(text())="i386"]'), 1)
        sel.click( # delete link inside cell beside "i386" cell
                '//table//td'
                '[normalize-space(preceding-sibling::td[1]/text())="i386"]'
                '//a[normalize-space(string(.))="Delete"]')
        sel.click("//button[@type='button' and .//text()='Yes']")
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'), 'i386 Removed')
        self.assertEquals(sel.get_xpath_count(
                '//div[@id="arches"]'
                '//td[normalize-space(text())="i386"]'), 0)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_add_key_value(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Key/Values"]')
        sel.type('key_name', 'NR_DISKS')
        sel.type('key_value', '100')
        sel.submit('name=keys')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_xpath_count(
                '//td[normalize-space(preceding-sibling::td[1]/text())'
                '="NR_DISKS" and '
                'normalize-space(text())="100"]'), 1)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_remove_key_value(self):
        with session.begin():
            self.system.key_values_int.append(
                    Key_Value_Int(Key.by_name(u'NR_DISKS'), 100))
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Key/Values"]')
        self.assertEquals(sel.get_xpath_count(
                '//td[normalize-space(preceding-sibling::td[1]/text())'
                '="NR_DISKS" and '
                'normalize-space(text())="100"]'), 1)
        sel.click( # delete link inside cell in row with NR_DISKS 100
                '//td[normalize-space(preceding-sibling::td[2]/text())="NR_DISKS" and '
                'normalize-space(preceding-sibling::td[1]/text())="100"'
                ']//a[normalize-space(string(.))="Delete"]')
        sel.click("//button[@type='button' and .//text()='Yes']")
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'), 'removed NR_DISKS/100')
        self.assertEquals(sel.get_xpath_count(
                '//td[normalize-space(preceding-sibling::td[1]/text())'
                '="NR_DISKS" and '
                'normalize-space(text())="100"]'), 0)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_add_group(self):
        with session.begin():
            group = data_setup.create_group()
            user_password = 'password'
            user = data_setup.create_user(password=user_password)
            data_setup.add_user_to_group(user, group)
            orig_date_modified = self.system.date_modified

        # as admin, assign the system to our test group
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Groups"]')
        sel.type("groups_group_text", group.group_name)
        sel.submit('name=groups')
        sel.wait_for_page_to_load("30000")
        self.assertEquals(sel.get_xpath_count(
                '//div[@id="groups"]'
                '//td[normalize-space(text())="%s"]' % group.group_name), 1)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

        # as a user in the group, can we see it?
        self.logout()
        self.login(user.user_name, user_password)
        sel.click("link=Available")
        sel.wait_for_page_to_load("30000")
        sel.type('simplesearch', self.system.fqdn)
        sel.submit('systemsearch_simple')
        sel.wait_for_page_to_load("30000")
        self.failUnless(sel.is_text_present(self.system.fqdn))

    def test_remove_group(self):
        with session.begin():
            group = data_setup.create_group()
            self.system.groups.append(group)
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Groups"]')
        self.assertEquals(sel.get_xpath_count(
                '//td[normalize-space(text())="%s"]' % group.group_name), 1)
        sel.click( # delete link inside cell in row with group name
                '//table//td[normalize-space(preceding-sibling::td[2]/text())="%s"]'
                '//a[normalize-space(string(.))="Delete"]' % group.group_name)
        sel.click("//button[@type='button' and .//text()='Yes']")
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'),
                '%s Removed' % group.display_name)
        self.assertEquals(sel.get_xpath_count(
                '//td[normalize-space(text())="%s"]' % group.group_name), 0)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_update_power(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Power Config"]')
        sel.select('name=power_type_id', 'drac')
        sel.type('name=power_address', 'nowhere.example.com')
        sel.type('name=power_user', 'asdf')
        sel.type('name=power_passwd', 'meh')
        sel.type('name=power_id', '1234')
        sel.click('//button[text()="Save Power Changes"]')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'), 'Updated Power')
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_add_install_options(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Install Options"]')
        sel.type('prov_ksmeta', 'skipx asdflol')
        sel.type('prov_koptions', 'init=/bin/true')
        sel.type('prov_koptionspost', 'vga=0x31b')
        sel.submit('name=installoptions')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), self.system.fqdn)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_delete_install_options(self):
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Install Options"]')
        sel.click('//tr[th/text()="Architecture"]//a') # Delete link
        sel.click("//button[@type='button' and .//text()='Yes']")
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_title(), self.system.fqdn)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)
            self.assert_(self.distro_tree.arch not in self.system.provisions)
            self.assertEquals(self.system.activity[0].action, u'Removed')
            self.assertEquals(self.system.activity[0].field_name,
                    u'InstallOption:kernel_options_post:i386')
            self.assertEquals(self.system.activity[1].action, u'Removed')
            self.assertEquals(self.system.activity[1].field_name,
                    u'InstallOption:kernel_options:i386')
            self.assertEquals(self.system.activity[2].action, u'Removed')
            self.assertEquals(self.system.activity[2].field_name,
                    u'InstallOption:ks_meta:i386')

    def test_update_labinfo(self):
        with session.begin():
            # Due to bz987313 system must have existing lab info
            self.system.labinfo = LabInfo(weight=100)
        orig_date_modified = self.system.date_modified
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Lab Info"]')
        changes = {
            'orig_cost': '1,000.00',
            'curr_cost': '500.00',
            'dimensions': '1x1x1',
            'weight': '50',
            'wattage': '500',
            'cooling': '1',
        }
        for k, v in changes.iteritems():
            sel.type(k, v)
        sel.click('//button[text()="Save Lab Info Changes"]')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_text('css=.flash'), 'Saved Lab Info')
        for k, v in changes.iteritems():
            self.assertEqual(sel.get_value(k), v)
        with session.begin():
            session.refresh(self.system)
            self.assert_(self.system.date_modified > orig_date_modified)

    def test_change_owner(self):
        with session.begin():
            new_owner = data_setup.create_user()
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click( # '(Change)' link inside cell beside 'Owner' cell
                '//div[normalize-space(label/text())="Owner"]'
                '//a[normalize-space(string(.))="Change"]')
        sel.wait_for_page_to_load('30000')
        sel.type('Owner_user', new_owner.user_name)
        sel.submit('Owner')
        sel.wait_for_page_to_load('30000')
        self.assertEquals(sel.get_title(), self.system.fqdn)
        self.assertEquals(sel.get_text('css=.flash'), 'OK')
        with session.begin():
            session.refresh(self.system)
            self.assertEquals(self.system.owner, new_owner)

    # https://bugzilla.redhat.com/show_bug.cgi?id=691796
    def test_cannot_set_owner_to_none(self):
        self.login()
        sel = self.selenium
        self.go_to_system_view()
        sel.click( # '(Change)' link inside cell beside 'Owner' cell
                '//div[normalize-space(label/text())="Owner"]'
                '//a[normalize-space(string(.))="Change"]')
        sel.wait_for_page_to_load('30000')
        sel.type('Owner_user', '')
        sel.submit('Owner')
        sel.wait_for_page_to_load('30000')
        self.assert_(sel.get_title().startswith('Change Owner'), sel.get_title())
        self.assert_(sel.is_element_present(
                '//span[@class="fielderror" and text()="Please enter a value"]'))
        with session.begin():
            session.refresh(self.system)
            self.assertEquals(self.system.owner, self.system_owner)

    # https://bugzilla.redhat.com/show_bug.cgi?id=706150
    def test_install_options_populated_on_provision_tab(self):
        self.login(self.unprivileged_user.user_name, 'password')
        sel = self.selenium
        self.go_to_system_view()
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Provision"]')
        sel.select('prov_install', unicode(self.distro_tree))
        self.wait_and_try(self.check_install_options)

    def check_install_options(self):
        sel = self.selenium
        self.assertEqual(sel.get_value('ks_meta'), 'some_ks_meta_var=3')
        # noverifyssl comes from server-test.cfg
        self.assertEqual(sel.get_value('koptions'), 'noverifyssl some_kernel_option=5')
        self.assertEqual(sel.get_value('koptions_post'), 'some_kernel_option=6')

    # https://bugzilla.redhat.com/show_bug.cgi?id=664482
    def test_cannot_change_lab_controller_while_system_in_use(self):
        with session.begin():
            self.system.reserve_manually(service=u'testdata',
                                         user=data_setup.create_user())
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.select('lab_controller_id', 'None')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assertEqual(sel.get_text('css=.flash'),
                'Unable to change lab controller while system is in use '
                '(return the system first)')
        self.assert_system_view_text('lab_controller_id', self.lab_controller.fqdn)

    # https://bugzilla.redhat.com/show_bug.cgi?id=714974
    def test_change_hypervisor(self):
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.select('hypervisor_id', 'KVM')
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assert_system_view_text('hypervisor_id', 'KVM')
        with session.begin():
            session.refresh(self.system)
            self.assertEqual(self.system.hypervisor, Hypervisor.by_name(u'KVM'))

    # https://bugzilla.redhat.com/show_bug.cgi?id=749441
    def test_mac_address_with_unicode(self):
        bad_mac_address = u'aяяяяяяяяяяяяяяяяя'
        self.login()
        sel = self.selenium
        self.go_to_system_edit()
        sel.type('mac_address', bad_mac_address)
        sel.click('link=Save Changes')
        sel.wait_for_page_to_load('30000')
        self.assert_system_view_text('mac_address', bad_mac_address)
        with session.begin():
            session.refresh(self.system)
            self.assertEqual(self.system.mac_address, bad_mac_address)

    #https://bugzilla.redhat.com/show_bug.cgi?id=833275
    def test_excluded_families(self):
        # Uses the default distro tree which goes by the name
        # of DansAwesomeLinux created in setUp()

        # append the x86_64 architecture to the system
        self.system.arch.append(Arch.by_name(u'x86_64'))

        # set up the distro tree for x86_64
        with session.begin():
            distro_tree = data_setup.create_distro_tree(arch=u'x86_64')
            self.system.provisions[distro_tree.arch] = Provision(arch=distro_tree.arch)

        self.go_to_system_view(self.system)
        sel = self.selenium

        # go to the Excluded Families Tab
        sel.click('//ul[@class="nav nav-tabs"]//a[text()="Excluded Families"]')

        # simulate the label click for i386
        sel.click('//li[normalize-space(text())="i386"]'
                  '//label[normalize-space(string(.))="DansAwesomeLinux6.9"]')
        # Now check if the appropriate checkbox was selected
        self.assertEquals(sel.is_checked('//input[@name="excluded_families_subsection.i386" and @value="%s"]' %
                                         self.distro_tree.distro.osversion_id), True)
        self.assertEquals(sel.is_checked('//input[@name="excluded_families_subsection.x86_64" and @value="%s"]' %
                                         self.distro_tree.distro.osversion_id), False)

        # Uncheck the i386 checkbox
        sel.uncheck('//input[@name="excluded_families_subsection.i386" and @value="%s"]' %
                    self.distro_tree.distro.osversion_id)

        # simulate the label click for x86_64
        sel.click('//li[normalize-space(text())="x86_64"]'
                  '//label[normalize-space(string(.))="DansAwesomeLinux6.9"]')
        # Now check if the appropriate checkbox was selected
        self.assertEquals(sel.is_checked('//input[@name="excluded_families_subsection.x86_64" and @value="%s"]' %
                                         self.distro_tree.distro.osversion_id), True)
        self.assertEquals(sel.is_checked('//input[@name="excluded_families_subsection.i386" and @value="%s"]' %
                                         self.distro_tree.distro.osversion_id), False)

class SystemCcTest(SeleniumTestCase):

    def setUp(self):
        with session.begin():
            user = data_setup.create_user(password=u'swordfish')
            self.system = data_setup.create_system(owner=user)
        self.selenium = self.get_selenium()
        self.selenium.start()
        self.login(user=user.user_name, password='swordfish')

    def tearDown(self):
        self.selenium.stop()

    def test_add_email_addresses(self):
        with session.begin():
            self.system.cc = []
        sel = self.selenium
        sel.open('cc_change?system_id=%s' % self.system.id)
        sel.wait_for_page_to_load('30000')
        assert not sel.get_value('cc_cc_0_email_address'), 'should be empty'
        sel.type('cc_cc_0_email_address', 'roy.baty@pkd.com')
        sel.click('doclink') # why the hell is it called this?
        sel.type('cc_cc_1_email_address', 'deckard@police.gov')
        sel.click('//input[@value="Change"]')
        sel.wait_for_page_to_load('30000')
        with session.begin():
            session.refresh(self.system)
            self.assertEquals(set(self.system.cc),
                    set([u'roy.baty@pkd.com', u'deckard@police.gov']))
            activity = self.system.activity[-1]
            self.assertEquals(activity.field_name, u'Cc')
            self.assertEquals(activity.service, u'WEBUI')
            self.assertEquals(activity.action, u'Changed')
            self.assertEquals(activity.old_value, u'')
            self.assertEquals(activity.new_value,
                    u'roy.baty@pkd.com; deckard@police.gov')

    def test_remove_email_addresses(self):
        with session.begin():
            self.system.cc = [u'roy.baty@pkd.com', u'deckard@police.gov']
        sel = self.selenium
        sel.open('cc_change?system_id=%s' % self.system.id)
        sel.wait_for_page_to_load('30000')
        sel.click('//tr[@id="cc_cc_1"]//a[text()="Remove (-)"]')
        #sel.click('//tr[@id="cc_cc_0"]//a[text()="Remove (-)"]')
        # The tg_expanding_widget javascript doesn't let us remove the last element,
        # so we have to just clear it instead :-S
        sel.type('cc_cc_0_email_address', '')
        sel.click('//input[@value="Change"]')
        sel.wait_for_page_to_load('30000')
        with session.begin():
            session.refresh(self.system)
            self.assertEquals(self.system.cc, [])
            activity = self.system.activity[-1]
            self.assertEquals(activity.field_name, u'Cc')
            self.assertEquals(activity.service, u'WEBUI')
            self.assertEquals(activity.action, u'Changed')
            self.assertEquals(activity.old_value,
                    u'deckard@police.gov; roy.baty@pkd.com')
            self.assertEquals(activity.new_value, u'')

    def test_replace_existing_email_address(self):
        with session.begin():
            self.system.cc = [u'roy.baty@pkd.com']
        sel = self.selenium
        sel.open('cc_change?system_id=%s' % self.system.id)
        sel.wait_for_page_to_load('30000')
        sel.type('cc_cc_0_email_address', 'deckard@police.gov')
        sel.click('//input[@value="Change"]')
        sel.wait_for_page_to_load('30000')
        with session.begin():
            session.refresh(self.system)
            self.assertEquals(self.system.cc, [u'deckard@police.gov'])
            activity = self.system.activity[-1]
            self.assertEquals(activity.field_name, u'Cc')
            self.assertEquals(activity.service, u'WEBUI')
            self.assertEquals(activity.action, u'Changed')
            self.assertEquals(activity.old_value, u'roy.baty@pkd.com')
            self.assertEquals(activity.new_value, u'deckard@police.gov')

class TestSystemViewRDF(unittest.TestCase):

    @with_transaction
    def setUp(self):
        self.system_owner = data_setup.create_user()
        self.system = data_setup.create_system(owner=self.system_owner)

    def test_turtle(self):
        rdf_url = urljoin(get_server_base(),
                'view/%s?%s' % (quote(self.system.fqdn.encode('utf8')),
                    urlencode({'tg_format': 'turtle'})))
        graph = rdflib.graph.Graph()
        graph.parse(location=rdf_url, format='n3')
        self.assert_(len(graph) >= 9)

    def test_rdfxml(self):
        rdf_url = urljoin(get_server_base(),
                'view/%s?%s' % (quote(self.system.fqdn.encode('utf8')),
                    urlencode({'tg_format': 'rdfxml'})))
        graph = rdflib.graph.Graph()
        graph.parse(location=rdf_url, format='xml')
        self.assert_(len(graph) >= 9)

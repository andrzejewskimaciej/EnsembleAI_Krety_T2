class AuthenticationError(Exception):
    pass

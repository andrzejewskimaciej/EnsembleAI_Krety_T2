class UnexpectedError(Exception):
    pass

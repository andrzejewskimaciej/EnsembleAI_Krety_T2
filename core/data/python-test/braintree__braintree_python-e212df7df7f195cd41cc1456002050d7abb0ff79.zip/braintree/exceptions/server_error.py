class ServerError(Exception):
    pass

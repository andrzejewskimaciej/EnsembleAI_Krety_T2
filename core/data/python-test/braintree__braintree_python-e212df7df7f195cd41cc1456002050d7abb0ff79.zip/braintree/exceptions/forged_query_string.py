class ForgedQueryStringError(Exception):
    pass

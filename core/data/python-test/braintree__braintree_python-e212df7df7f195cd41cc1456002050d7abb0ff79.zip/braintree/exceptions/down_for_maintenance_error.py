class DownForMaintenanceError(Exception):
    pass

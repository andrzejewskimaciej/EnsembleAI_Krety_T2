
#
# rpclib - Copyright (C) Rpclib contributors.
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
#

"""Module that contains backends that process the auxiliary contexts. These
result from non-primary functions in service definitions.

Classes from this package will have the ``AuxProc`` suffix, short for 
"Auxiliary Processor". Sounds neat, huh? :)

This package is EXPERIMENTAL. Stay away from it.
"""

from rpclib.aux._base import LOG_ERRORS
from rpclib.aux._base import RETRY_ERRORS
from rpclib.aux._base import AuxProcBase


.. automodule:: bkr.client.wizard

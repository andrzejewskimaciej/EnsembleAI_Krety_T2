pychemia package
================

.. automodule:: pychemia
    :members:
    :undoc-members:
    :show-inheritance:

Subpackages
-----------

.. toctree::

    pychemia.analysis
    pychemia.code
    pychemia.core
    pychemia.crystal
    pychemia.db
    pychemia.dm
    pychemia.evaluator
    pychemia.external
    pychemia.io
    pychemia.md
    pychemia.population
    pychemia.runner
    pychemia.searcher
    pychemia.test
    pychemia.utils
    pychemia.visual
    pychemia.web

